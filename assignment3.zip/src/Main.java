import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        GroceryList x= new GroceryList();
        for(int i = 0;i<10;i++){
            Scanner Name = new Scanner(System.in);
            Scanner Quantity = new Scanner(System.in);
            Scanner Price = new Scanner(System.in);
            int Q = Quantity.nextInt();
            double PriceItem;
            GroceryItemOrder item = new GroceryItemOrder(Name.next(),Price.nextDouble());
            item.setQuantity(Q);
            x.add(item);
            PriceItem = item.getCost();
            System.out.println(PriceItem);

        }
        double A = 0;
        for ( int i=0;i<x.list.size();i++) {
            A = x.getTotalCost();
        }
        System.out.println(A);
    }
}