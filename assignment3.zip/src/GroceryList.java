import java.util.ArrayList;

public class GroceryList {
    ArrayList<GroceryItemOrder> list= new ArrayList<>(10);

    public GroceryList(){}
    public void add(GroceryItemOrder item){
        if (list.size()<=10)
            list.add(item);
        else
            System.out.println("cannot add items");
    }
    public double  getTotalCost(){

        double x=0;
        for (GroceryItemOrder a: list){
            x=x+a.getCost();
        }
        return x;
    }
}

class GroceryItemOrder{
    public String name;
    public int quantity;

    public double PricePerUnit;

    public GroceryItemOrder(String name, double pricePerUnit) {
        this.name = name;
        PricePerUnit = pricePerUnit;
    }

    public double getCost(){
        return quantity*PricePerUnit;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}


