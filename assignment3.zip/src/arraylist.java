import java.util.ArrayList;

public class arraylist {
    public static Integer max( ArrayList<Integer> List) {
        int x = Integer.MIN_VALUE;
        for (int i = 1; i <= List.size(); i++) {
            if (List.get(i) > x) {
                x = List.get(i);
            }
        }
        if (List == null || List.size() == 0)
            return null;
        else
            return x;


    }
}
